/* hello.c */

int printf(char *s, ...);

int main(void)
{
    printf("hello world\n");
}
